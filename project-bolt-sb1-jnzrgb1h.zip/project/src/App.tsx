import React, { useState } from 'react';
import { Eye, EyeOff, Mail, Lock, LogIn, ToggleLeft as Google } from 'lucide-react';

function App() {
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle login logic here
  };

  return (
    <div className="min-h-screen bg-gray-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-gray-800 rounded-xl shadow-2xl overflow-hidden transform transition-all hover:shadow-[0_0_40px_rgba(34,197,94,0.15)]">
        <div className="p-8">
          <h2 className="text-3xl font-bold text-center text-white mb-8">Login</h2>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="University Email"
                  className="w-full bg-gray-700 text-white rounded-lg pl-10 pr-4 py-3 border border-gray-600 focus:border-green-500 focus:ring-2 focus:ring-green-500 focus:ring-opacity-20 outline-none transition-all"
                />
              </div>
            </div>

            <div className="space-y-2">
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Password"
                  className="w-full bg-gray-700 text-white rounded-lg pl-10 pr-12 py-3 border border-gray-600 focus:border-green-500 focus:ring-2 focus:ring-green-500 focus:ring-opacity-20 outline-none transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-300 transition-colors"
                >
                  {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-green-600 hover:bg-green-700 text-white font-semibold rounded-lg py-3 flex items-center justify-center space-x-2 transition-colors duration-200"
            >
              <LogIn className="h-5 w-5" />
              <span>Login</span>
            </button>

            <div className="relative flex items-center justify-center">
              <div className="border-t border-gray-600 w-full"></div>
              <span className="bg-gray-800 px-4 text-sm text-gray-400">or</span>
              <div className="border-t border-gray-600 w-full"></div>
            </div>

            <button
              type="button"
              className="w-full bg-gray-700 hover:bg-gray-600 text-white font-semibold rounded-lg py-3 flex items-center justify-center space-x-2 transition-colors duration-200"
            >
              <Google className="h-5 w-5" />
              <span>Sign in with Google</span>
            </button>

            <p className="text-center text-gray-400">
              Don't have an account?{' '}
              <a href="#" className="text-green-500 hover:text-green-400 font-semibold transition-colors">
                Sign up
              </a>
            </p>
          </form>
        </div>
      </div>
    </div>
  );
}

export default App;