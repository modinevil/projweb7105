import { Platform, StudentProgress } from './types';

export const platforms: Platform[] = [
  {
    id: 'leetcode',
    name: 'LeetCode',
    icon: 'code-2',
    maxScore: 3000
  },
  {
    id: 'hackerrank',
    name: 'HackerRank',
    icon: 'terminal',
    maxScore: 1000
  },
  {
    id: 'coursera',
    name: 'Coursera',
    icon: 'graduation-cap',
    maxScore: 500
  }
];

export const mockStudentData: StudentProgress[] = [
  {
    student: {
      id: '1',
      name: 'Alex Johnson',
      email: 'alex.j@university.edu',
      avatar: 'https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=100&h=100&fit=crop'
    },
    platforms: [
      {
        platform: 'leetcode',
        score: 2450,
        progress: 82,
        lastUpdated: '2024-03-10'
      },
      {
        platform: 'hackerrank',
        score: 850,
        progress: 85,
        lastUpdated: '2024-03-12'
      },
      {
        platform: 'coursera',
        score: 475,
        progress: 95,
        lastUpdated: '2024-03-11'
      }
    ],
    overallRank: 1,
    overallProgress: 87
  },
  {
    student: {
      id: '2',
      name: 'Sarah Chen',
      email: 'sarah.c@university.edu',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop'
    },
    platforms: [
      {
        platform: 'leetcode',
        score: 2300,
        progress: 77,
        lastUpdated: '2024-03-11'
      },
      {
        platform: 'hackerrank',
        score: 920,
        progress: 92,
        lastUpdated: '2024-03-12'
      },
      {
        platform: 'coursera',
        score: 450,
        progress: 90,
        lastUpdated: '2024-03-10'
      }
    ],
    overallRank: 2,
    overallProgress: 86
  },
  {
    student: {
      id: '3',
      name: 'Michael Brown',
      email: 'michael.b@university.edu',
      avatar: 'https://images.unsplash.com/photo-1639149888905-fb39731f2e6c?w=100&h=100&fit=crop'
    },
    platforms: [
      {
        platform: 'leetcode',
        score: 2100,
        progress: 70,
        lastUpdated: '2024-03-12'
      },
      {
        platform: 'hackerrank',
        score: 780,
        progress: 78,
        lastUpdated: '2024-03-11'
      },
      {
        platform: 'coursera',
        score: 425,
        progress: 85,
        lastUpdated: '2024-03-12'
      }
    ],
    overallRank: 3,
    overallProgress: 78
  }
];