import React from 'react';
import { GraduationCap } from 'lucide-react';
import { StudentCard } from './components/StudentCard';
import { PlatformStats } from './components/PlatformStats';
import { mockStudentData, platforms } from './data';

function App() {
  const calculatePlatformStats = (platformId: string) => {
    const students = mockStudentData.length;
    const platformScores = mockStudentData.map(
      student => student.platforms.find(p => p.platform === platformId)!
    );
    
    const avgScore = Math.round(
      platformScores.reduce((acc, curr) => acc + curr.score, 0) / students
    );
    
    const avgProgress = Math.round(
      platformScores.reduce((acc, curr) => acc + curr.progress, 0) / students
    );

    return {
      totalStudents: students,
      averageScore: avgScore,
      averageProgress: avgProgress,
    };
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex items-center gap-3 mb-8">
          <GraduationCap className="w-8 h-8 text-indigo-600" />
          <h1 className="text-2xl font-bold text-gray-900">Faculty Dashboard</h1>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {platforms.map(platform => (
            <PlatformStats
              key={platform.id}
              platform={platform}
              {...calculatePlatformStats(platform.id)}
            />
          ))}
        </div>

        <h2 className="text-xl font-semibold text-gray-900 mb-6">Student Rankings</h2>
        
        <div className="space-y-6">
          {mockStudentData.map(student => (
            <StudentCard key={student.student.id} student={student} />
          ))}
        </div>
      </div>
    </div>
  );
}

export default App;