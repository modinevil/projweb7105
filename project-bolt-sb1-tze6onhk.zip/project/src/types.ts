export interface Student {
  id: string;
  name: string;
  email: string;
  avatar: string;
}

export interface PlatformScore {
  platform: string;
  score: number;
  progress: number;
  lastUpdated: string;
}

export interface StudentProgress {
  student: Student;
  platforms: PlatformScore[];
  overallRank: number;
  overallProgress: number;
}

export interface Platform {
  id: string;
  name: string;
  icon: string;
  maxScore: number;
}