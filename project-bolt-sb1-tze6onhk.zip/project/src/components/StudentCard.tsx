import React from 'react';
import { StudentProgress } from '../types';
import { Trophy, Medal } from 'lucide-react';

interface StudentCardProps {
  student: StudentProgress;
}

const getRankIcon = (rank: number) => {
  switch (rank) {
    case 1:
      return <Trophy className="w-6 h-6 text-yellow-500" />;
    case 2:
      return <Medal className="w-6 h-6 text-gray-400" />;
    case 3:
      return <Medal className="w-6 h-6 text-amber-700" />;
    default:
      return null;
  }
};

export const StudentCard: React.FC<StudentCardProps> = ({ student }) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
      <div className="flex items-center gap-4">
        <img
          src={student.student.avatar}
          alt={student.student.name}
          className="w-16 h-16 rounded-full object-cover"
        />
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <h3 className="text-lg font-semibold">{student.student.name}</h3>
            {getRankIcon(student.overallRank)}
          </div>
          <p className="text-gray-600">{student.student.email}</p>
        </div>
        <div className="text-right">
          <div className="text-2xl font-bold text-indigo-600">
            #{student.overallRank}
          </div>
          <div className="text-sm text-gray-500">Overall Rank</div>
        </div>
      </div>
      
      <div className="mt-4">
        <div className="mb-2 flex justify-between items-center">
          <span className="text-sm font-medium text-gray-700">Overall Progress</span>
          <span className="text-sm font-semibold">{student.overallProgress}%</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div
            className="bg-indigo-600 h-2 rounded-full"
            style={{ width: `${student.overallProgress}%` }}
          />
        </div>
      </div>

      <div className="mt-4 space-y-3">
        {student.platforms.map((platform) => (
          <div key={platform.platform} className="flex items-center justify-between">
            <span className="text-sm font-medium text-gray-700">
              {platform.platform.charAt(0).toUpperCase() + platform.platform.slice(1)}
            </span>
            <div className="flex items-center gap-4">
              <span className="text-sm font-semibold">{platform.score}</span>
              <div className="w-24 bg-gray-200 rounded-full h-1.5">
                <div
                  className="bg-green-500 h-1.5 rounded-full"
                  style={{ width: `${platform.progress}%` }}
                />
              </div>
              <span className="text-sm text-gray-500">{platform.progress}%</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};