import React from 'react';
import { Platform } from '../types';
import * as icons from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

interface PlatformStatsProps {
  platform: Platform;
  totalStudents: number;
  averageScore: number;
  averageProgress: number;
}

export const PlatformStats: React.FC<PlatformStatsProps> = ({
  platform,
  totalStudents,
  averageScore,
  averageProgress,
}) => {
  const IconComponent = (icons[platform.icon as keyof typeof icons] as LucideIcon) || icons.HelpCircle;

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center gap-3">
        <div className="p-3 bg-indigo-100 rounded-lg">
          <IconComponent className="w-6 h-6 text-indigo-600" />
        </div>
        <h3 className="text-lg font-semibold">{platform.name}</h3>
      </div>
      
      <div className="mt-4 grid grid-cols-3 gap-4">
        <div>
          <div className="text-2xl font-bold text-gray-900">{totalStudents}</div>
          <div className="text-sm text-gray-500">Students</div>
        </div>
        <div>
          <div className="text-2xl font-bold text-gray-900">{averageScore}</div>
          <div className="text-sm text-gray-500">Avg Score</div>
        </div>
        <div>
          <div className="text-2xl font-bold text-gray-900">{averageProgress}%</div>
          <div className="text-sm text-gray-500">Avg Progress</div>
        </div>
      </div>

      <div className="mt-4">
        <div className="flex justify-between items-center mb-1">
          <span className="text-sm font-medium text-gray-700">Overall Progress</span>
          <span className="text-sm font-semibold">{averageProgress}%</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div
            className="bg-indigo-600 h-2 rounded-full"
            style={{ width: `${averageProgress}%` }}
          />
        </div>
      </div>
    </div>
  );
};