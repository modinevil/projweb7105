import React from 'react';
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  AreaChart, Area
} from 'recharts';
import { 
  Trophy, Star, Award, Youtube, BookOpen, Calendar, 
  ChevronRight, Settings, Sun, Code2, Target, Laptop2
} from 'lucide-react';

const performanceData = [
  { name: 'Mon', problems: 4 },
  { name: 'Tue', problems: 3 },
  { name: 'Wed', problems: 7 },
  { name: 'Thu', problems: 5 },
  { name: 'Fri', problems: 8 },
  { name: 'Sat', problems: 12 },
  { name: 'Sun', problems: 6 },
];

const ratingData = [
  { name: 'Jan', rating: 1800 },
  { name: 'Feb', rating: 1850 },
  { name: 'Mar', rating: 1900 },
  { name: 'Apr', rating: 1950 },
  { name: 'May', rating: 2100 },
];

function App() {
  return (
    <div className="min-h-screen bg-gray-900 text-gray-100">
      {/* Header */}
      <header className="bg-gray-800 border-b border-gray-700">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-emerald-400">CodeTracker</h1>
          <div className="flex items-center gap-4">
            <button className="p-2 hover:bg-gray-700 rounded-lg">
              <Settings className="w-5 h-5" />
            </button>
            <button className="p-2 hover:bg-gray-700 rounded-lg">
              <Sun className="w-5 h-5" />
            </button>
            <div className="w-10 h-10 rounded-full bg-emerald-500 flex items-center justify-center">
              <span className="font-semibold">CC</span>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          <div className="lg:col-span-2 bg-gray-800 rounded-xl p-6 flex items-center gap-6">
            <div className="w-24 h-24 rounded-full bg-emerald-500 flex items-center justify-center text-3xl font-bold">
              CC
            </div>
            <div>
              <h2 className="text-2xl font-bold mb-2">Hey, Christopher! 👋</h2>
              <p className="text-gray-400">Ready to Code Today?</p>
              <div className="flex gap-4 mt-4">
                <span className="px-3 py-1 bg-gray-700 rounded-full text-sm">Class Rank: #2</span>
                <span className="px-3 py-1 bg-gray-700 rounded-full text-sm">University Rank: #10</span>
              </div>
            </div>
          </div>
          <div className="bg-gray-800 rounded-xl p-6">
            <h3 className="font-semibold mb-4">Quick Actions</h3>
            <button className="w-full bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg px-4 py-3 mb-3 flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Code2 className="w-5 h-5" />
                Solve Today's Problem
              </span>
              <ChevronRight className="w-5 h-5" />
            </button>
            <button className="w-full bg-gray-700 hover:bg-gray-600 rounded-lg px-4 py-3 flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Target className="w-5 h-5" />
                Set Daily Goal
              </span>
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-gray-800 rounded-xl p-6">
            <div className="flex items-center gap-3 mb-2">
              <Trophy className="w-5 h-5 text-yellow-500" />
              <h3 className="font-semibold">Problems Solved</h3>
            </div>
            <p className="text-3xl font-bold">350+</p>
            <p className="text-sm text-gray-400 mt-1">+24 this week</p>
          </div>
          <div className="bg-gray-800 rounded-xl p-6">
            <div className="flex items-center gap-3 mb-2">
              <Star className="w-5 h-5 text-yellow-500" />
              <h3 className="font-semibold">LeetCode Rating</h3>
            </div>
            <p className="text-3xl font-bold">2100</p>
            <p className="text-sm text-emerald-400 mt-1">↑ 150 points</p>
          </div>
          <div className="bg-gray-800 rounded-xl p-6">
            <div className="flex items-center gap-3 mb-2">
              <Award className="w-5 h-5 text-yellow-500" />
              <h3 className="font-semibold">Contests Won</h3>
            </div>
            <p className="text-3xl font-bold">2</p>
            <p className="text-sm text-gray-400 mt-1">CodeChef Long Challenge</p>
          </div>
          <div className="bg-gray-800 rounded-xl p-6">
            <div className="flex items-center gap-3 mb-2">
              <Laptop2 className="w-5 h-5 text-yellow-500" />
              <h3 className="font-semibold">Current Streak</h3>
            </div>
            <p className="text-3xl font-bold">7 days</p>
            <p className="text-sm text-emerald-400 mt-1">Personal Best!</p>
          </div>
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          <div className="bg-gray-800 rounded-xl p-6">
            <h3 className="font-semibold mb-4">Weekly Progress</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={performanceData}>
                  <defs>
                    <linearGradient id="colorProblems" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis dataKey="name" stroke="#9ca3af" />
                  <YAxis stroke="#9ca3af" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#1f2937',
                      border: 'none',
                      borderRadius: '8px',
                      boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'
                    }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="problems" 
                    stroke="#10b981" 
                    fillOpacity={1} 
                    fill="url(#colorProblems)" 
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
          <div className="bg-gray-800 rounded-xl p-6">
            <h3 className="font-semibold mb-4">Rating Progression</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={ratingData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis dataKey="name" stroke="#9ca3af" />
                  <YAxis stroke="#9ca3af" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#1f2937',
                      border: 'none',
                      borderRadius: '8px',
                      boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'
                    }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="rating" 
                    stroke="#10b981" 
                    strokeWidth={2} 
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Bottom Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="bg-gray-800 rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold">Upcoming Contests</h3>
              <Calendar className="w-5 h-5 text-gray-400" />
            </div>
            <div className="space-y-4">
              <div className="bg-gray-700 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium">LeetCode Biweekly Contest</h4>
                  <span className="text-emerald-400 text-sm">2 days left</span>
                </div>
                <p className="text-sm text-gray-400">Duration: 1.5 hours</p>
              </div>
              <div className="bg-gray-700 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium">CodeChef Long Challenge</h4>
                  <span className="text-emerald-400 text-sm">5 days left</span>
                </div>
                <p className="text-sm text-gray-400">Duration: 10 days</p>
              </div>
            </div>
          </div>

          <div className="bg-gray-800 rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold">Learning Resources</h3>
              <BookOpen className="w-5 h-5 text-gray-400" />
            </div>
            <div className="space-y-4">
              <div className="bg-gray-700 rounded-lg p-4">
                <h4 className="font-medium mb-2">Focus Areas</h4>
                <div className="flex flex-wrap gap-2">
                  <span className="px-3 py-1 bg-gray-600 rounded-full text-sm">Graphs</span>
                  <span className="px-3 py-1 bg-gray-600 rounded-full text-sm">Dynamic Programming</span>
                </div>
              </div>
              <div className="bg-gray-700 rounded-lg p-4">
                <h4 className="font-medium mb-2">Recommended Videos</h4>
                <div className="flex items-center gap-2 text-emerald-400">
                  <Youtube className="w-4 h-4" />
                  <a href="#" className="text-sm hover:underline">Graph Algorithms Masterclass</a>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-gray-800 rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold">Faculty Mentorship</h3>
              <Settings className="w-5 h-5 text-gray-400" />
            </div>
            <div className="mb-4">
              <p className="text-sm text-gray-400">Assigned Mentor</p>
              <p className="font-medium">R.D. Sharma</p>
            </div>
            <div className="bg-gray-700 rounded-lg p-4">
              <h4 className="font-medium mb-2">Latest Feedback</h4>
              <p className="text-sm text-gray-300">
                "Great progress on algorithms. Focus more on system design concepts for upcoming interviews."
              </p>
              <p className="text-xs text-gray-400 mt-2">Updated 2 days ago</p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;