"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Edit, Award, Star, ChevronRight } from "lucide-react"
import { cn } from "@/lib/utils"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export default function StudentProfile() {
  const [loaded, setLoaded] = useState(false)

  useEffect(() => {
    setLoaded(true)
  }, [])

  // Mock student data - would be fetched from API in a real application
  const student = {
    name: "Christopher Columbus",
    profilePic: "/placeholder.svg?height=100&width=100",
    classRank: 3,
    universityRank: 12,
    university: "Parul University",
    enrollmentNumber: "123456789",
    email: "christopher@paruluniversity.edu",
    personalEmail: "chris.personal@email.com",
    badges: [
      { id: 1, name: "Daily_Coder", description: "Coded for 30 consecutive days" },
      { id: 2, name: "Problem_Solver", description: "Solved 100+ coding problems" },
      { id: 3, name: "100_DaysOfCode", description: "Completed the 100 days of code challenge" },
      { id: 4, name: "Algorithm_Master", description: "Mastered advanced algorithms" },
    ],
    codingAccounts: [
      { name: "LeetCode", url: "https://leetcode.com/user", icon: "L" },
      { name: "HackerRank", url: "https://hackerrank.com/user", icon: "H" },
      { name: "CodeChef", url: "https://codechef.com/user", icon: "C" },
    ],
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: "spring",
        stiffness: 100,
      },
    },
  }

  return (
    <div
      className={cn(
        "min-h-screen bg-gray-950 p-6 text-gray-200 transition-opacity duration-500",
        loaded ? "opacity-100" : "opacity-0",
      )}
    >
      <div className="mx-auto max-w-4xl">
        {/* Header Section */}
        <motion.div initial="hidden" animate="visible" variants={containerVariants} className="mb-8">
          <motion.h1 variants={itemVariants} className="text-3xl font-bold text-white">
            Hey, Christopher
          </motion.h1>
          <motion.p variants={itemVariants} className="text-lg text-gray-400">
            Profile
          </motion.p>
        </motion.div>

        {/* Profile Overview Section */}
        <motion.div
          initial="hidden"
          animate="visible"
          variants={containerVariants}
          className="mb-8 overflow-hidden rounded-xl bg-gray-900 p-6 shadow-lg"
        >
          <div className="flex flex-col gap-6 md:flex-row">
            {/* Left Side - Profile Picture and Name */}
            <motion.div variants={itemVariants} className="flex flex-col items-center md:items-start">
              <Avatar className="h-24 w-24 border-2 border-green-500 shadow-[0_0_15px_rgba(34,197,94,0.3)]">
                <AvatarImage src={student.profilePic} alt={student.name} />
                <AvatarFallback className="bg-green-900 text-xl text-white">
                  {student.name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")}
                </AvatarFallback>
              </Avatar>
              <h2 className="mt-4 text-xl font-semibold text-white">{student.name}</h2>
            </motion.div>

            {/* Right Side - Ranks and Connected Accounts */}
            <motion.div variants={itemVariants} className="flex flex-1 flex-col justify-between gap-4">
              {/* Ranks */}
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div className="rounded-lg bg-gray-800 p-4 transition-all duration-300 hover:bg-gray-800/80 hover:shadow-md">
                  <div className="flex items-center gap-2">
                    <Star className="h-5 w-5 text-yellow-500" />
                    <span className="text-sm text-gray-400">Class Rank</span>
                  </div>
                  <p className="mt-1 text-2xl font-bold text-white">#{student.classRank}</p>
                </div>
                <div className="rounded-lg bg-gray-800 p-4 transition-all duration-300 hover:bg-gray-800/80 hover:shadow-md">
                  <div className="flex items-center gap-2">
                    <Award className="h-5 w-5 text-yellow-500" />
                    <span className="text-sm text-gray-400">University Rank</span>
                  </div>
                  <p className="mt-1 text-2xl font-bold text-white">#{student.universityRank}</p>
                </div>
              </div>

              {/* Connected Accounts */}
              <div>
                <h3 className="mb-3 text-sm font-medium text-gray-400">Connected Coding Accounts</h3>
                <div className="flex flex-wrap gap-3">
                  {student.codingAccounts.map((account, index) => (
                    <a
                      key={index}
                      href={account.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex h-10 w-10 items-center justify-center rounded-full bg-gray-800 text-white transition-all duration-300 hover:bg-green-900 hover:shadow-[0_0_10px_rgba(34,197,94,0.5)]"
                      title={account.name}
                    >
                      {account.icon}
                    </a>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </motion.div>

        {/* User Information Section */}
        <motion.div
          initial="hidden"
          animate="visible"
          variants={containerVariants}
          className="mb-8 overflow-hidden rounded-xl bg-gray-900 p-6 shadow-lg"
        >
          <motion.h3 variants={itemVariants} className="mb-4 text-lg font-semibold text-white">
            User Information
          </motion.h3>
          <motion.div variants={itemVariants} className="grid gap-4 md:grid-cols-2">
            <div className="space-y-1">
              <p className="text-sm text-gray-400">University</p>
              <p className="font-medium text-white">{student.university}</p>
            </div>
            <div className="space-y-1">
              <p className="text-sm text-gray-400">Enrollment Number</p>
              <p className="font-medium text-white">{student.enrollmentNumber}</p>
            </div>
            <div className="space-y-1">
              <p className="text-sm text-gray-400">University Email</p>
              <p className="font-medium text-white">{student.email}</p>
            </div>
            <div className="space-y-1">
              <p className="text-sm text-gray-400">Personal Email</p>
              <p className="font-medium text-white">{student.personalEmail}</p>
            </div>
          </motion.div>
        </motion.div>

        {/* Badges & Achievements Section */}
        <motion.div
          initial="hidden"
          animate="visible"
          variants={containerVariants}
          className="mb-8 overflow-hidden rounded-xl bg-gray-900 p-6 shadow-lg"
        >
          <motion.div variants={itemVariants} className="mb-4 flex items-center justify-between">
            <h3 className="text-lg font-semibold text-white">Badges & Achievements</h3>
            <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
              View All <ChevronRight className="ml-1 h-4 w-4" />
            </Button>
          </motion.div>
          <motion.div variants={itemVariants} className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-4">
            {student.badges.map((badge) => (
              <Card
                key={badge.id}
                className="group overflow-hidden border-green-900/20 bg-gray-800 transition-all duration-300 hover:border-green-500/50 hover:shadow-[0_0_15px_rgba(34,197,94,0.2)]"
              >
                <CardContent className="p-4">
                  <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-full bg-green-900/30 text-green-500 transition-all duration-300 group-hover:bg-green-900/50 group-hover:text-green-400">
                    <Award className="h-6 w-6" />
                  </div>
                  <h4 className="mb-1 font-medium text-white">#{badge.name}</h4>
                  <p className="text-xs text-gray-400">{badge.description}</p>
                </CardContent>
              </Card>
            ))}
          </motion.div>
        </motion.div>

        {/* Edit Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="flex justify-end"
        >
          <Button className="bg-green-600 text-white hover:bg-green-700">
            <Edit className="mr-2 h-4 w-4" /> Edit Information
          </Button>
        </motion.div>
      </div>
    </div>
  )
}

