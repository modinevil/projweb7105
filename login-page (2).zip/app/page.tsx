"use client"

import LoginPage from "../login-page"

export default function SyntheticV0PageForDeployment() {
  return <LoginPage />
}