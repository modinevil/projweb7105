"use client"

import FacultyProfile from "../faculty-profile"

export default function SyntheticV0PageForDeployment() {
  return <FacultyProfile />
}