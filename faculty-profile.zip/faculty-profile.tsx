"use client"

import { useState } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Award, Code, Edit2, ExternalLink, Mail, MapPin, Star, Trophy, Users } from "lucide-react"

export default function FacultyProfile() {
  const [activeTab, setActiveTab] = useState("achievements")

  return (
    <div className="min-h-screen bg-zinc-900 text-zinc-100 p-4 md:p-8">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <h1 className="text-2xl md:text-3xl font-bold">Hey, R.D. Sharma</h1>
          <h2 className="text-lg text-emerald-400">Profile</h2>
        </div>

        {/* Profile Overview */}
        <Card className="bg-zinc-800 border-zinc-700">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-6">
              <div className="flex flex-col items-center md:items-start gap-3">
                <Avatar className="w-32 h-32 border-2 border-emerald-500">
                  <AvatarImage src="/placeholder.svg?height=128&width=128" alt="R.D. Sharma" />
                  <AvatarFallback className="bg-emerald-900 text-emerald-100 text-2xl">RDS</AvatarFallback>
                </Avatar>
                <h2 className="text-xl font-bold">R.D. Sharma</h2>
              </div>

              <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card className="bg-zinc-700/50 border-zinc-600 hover:bg-zinc-700 transition-colors">
                  <CardContent className="p-4 flex items-center gap-3">
                    <div className="p-3 rounded-full bg-emerald-900/50 text-emerald-400">
                      <Users size={24} />
                    </div>
                    <div>
                      <p className="text-sm text-zinc-400">Students Under Guidance</p>
                      <p className="text-2xl font-bold">56</p>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-zinc-700/50 border-zinc-600 hover:bg-zinc-700 transition-colors">
                  <CardContent className="p-4 flex items-center gap-3">
                    <div className="p-3 rounded-full bg-emerald-900/50 text-emerald-400">
                      <Trophy size={24} />
                    </div>
                    <div>
                      <p className="text-sm text-zinc-400">Faculty Rank</p>
                      <p className="text-2xl font-bold">#4</p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Faculty Information */}
        <Card className="bg-zinc-800 border-zinc-700">
          <CardHeader>
            <CardTitle>Faculty Information</CardTitle>
            <CardDescription className="text-zinc-400">Personal and professional details</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <MapPin className="text-emerald-400" size={18} />
                  <div>
                    <p className="text-sm text-zinc-400">University</p>
                    <p>Parul University</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Code className="text-emerald-400" size={18} />
                  <div>
                    <p className="text-sm text-zinc-400">Department</p>
                    <p>Computer Science & Engineering</p>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <Mail className="text-emerald-400" size={18} />
                  <div>
                    <p className="text-sm text-zinc-400">University Email</p>
                    <p>rdsharma@paruluniversity.edu</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Mail className="text-emerald-400" size={18} />
                  <div>
                    <p className="text-sm text-zinc-400">Personal Email</p>
                    <p>rdsharma.personal@email.com</p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Tabs for Achievements and Student Performance */}
        <Tabs defaultValue="achievements" value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid grid-cols-2 bg-zinc-800 border border-zinc-700">
            <TabsTrigger
              value="achievements"
              className="data-[state=active]:bg-emerald-900/30 data-[state=active]:text-emerald-400"
            >
              Achievements
            </TabsTrigger>
            <TabsTrigger
              value="students"
              className="data-[state=active]:bg-emerald-900/30 data-[state=active]:text-emerald-400"
            >
              Student Performance
            </TabsTrigger>
          </TabsList>

          {/* Achievements Tab */}
          <TabsContent value="achievements" className="mt-4 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <AchievementCard
                icon={<Users />}
                title="Internship Success"
                description="Guided 10+ students to crack internships at top tech firms"
              />

              <AchievementCard
                icon={<Star />}
                title="Coding Excellence"
                description="Mentored 20+ students in achieving 5-star ratings on CodeChef"
              />

              <AchievementCard
                icon={<Award />}
                title="Event Organization"
                description="Organized 3+ hackathons in collaboration with industry experts"
              />
            </div>

            <Card className="bg-zinc-800 border-zinc-700 mt-6">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Code size={20} className="text-emerald-400" />
                  Connected Coding Accounts
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-3">
                  <Badge
                    variant="outline"
                    className="flex items-center gap-1 py-2 px-3 bg-zinc-700 hover:bg-zinc-600 cursor-pointer transition-colors"
                  >
                    <span>LeetCode</span>
                    <ExternalLink size={14} />
                  </Badge>
                  <Badge
                    variant="outline"
                    className="flex items-center gap-1 py-2 px-3 bg-zinc-700 hover:bg-zinc-600 cursor-pointer transition-colors"
                  >
                    <span>HackerRank</span>
                    <ExternalLink size={14} />
                  </Badge>
                  <Badge
                    variant="outline"
                    className="flex items-center gap-1 py-2 px-3 bg-zinc-700 hover:bg-zinc-600 cursor-pointer transition-colors"
                  >
                    <span>CodeChef</span>
                    <ExternalLink size={14} />
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Student Performance Tab */}
          <TabsContent value="students" className="mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <StudentCard
                name="Christopher Columbus"
                achievement="LeetCode Top 1% Coder"
                avatarSrc="/placeholder.svg?height=40&width=40"
              />

              <StudentCard
                name="Jessica Brown"
                achievement="Won Google Hackathon"
                avatarSrc="/placeholder.svg?height=40&width=40"
              />

              <StudentCard
                name="Michael Johnson"
                achievement="Published research paper"
                avatarSrc="/placeholder.svg?height=40&width=40"
              />

              <StudentCard
                name="Sarah Williams"
                achievement="Secured internship at Microsoft"
                avatarSrc="/placeholder.svg?height=40&width=40"
              />
            </div>

            <div className="mt-8 p-6 bg-zinc-800 border border-zinc-700 rounded-lg">
              <h3 className="text-lg font-medium mb-4">Student Progress Overview</h3>
              <div className="h-64 flex items-center justify-center">
                <p className="text-zinc-400">Interactive student progress graph will appear here</p>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        {/* Edit Profile Button */}
        <div className="flex justify-end">
          <Button className="bg-emerald-600 hover:bg-emerald-700 text-white">
            <Edit2 className="mr-2 h-4 w-4" /> Edit Profile
          </Button>
        </div>
      </div>
    </div>
  )
}

function AchievementCard({ icon, title, description }) {
  return (
    <Card className="bg-zinc-800 border-zinc-700 overflow-hidden group hover:border-emerald-500/50 transition-all duration-300">
      <CardContent className="p-6">
        <div className="p-3 rounded-full bg-emerald-900/30 text-emerald-400 w-fit mb-4 group-hover:bg-emerald-900/50 transition-colors">
          {icon}
        </div>
        <h3 className="font-medium text-lg mb-2">{title}</h3>
        <p className="text-zinc-400">{description}</p>
      </CardContent>
    </Card>
  )
}

function StudentCard({ name, achievement, avatarSrc }) {
  return (
    <Card className="bg-zinc-800 border-zinc-700 hover:bg-zinc-750 transition-colors">
      <CardContent className="p-4 flex items-center gap-4">
        <Avatar>
          <AvatarImage src={avatarSrc} alt={name} />
          <AvatarFallback className="bg-emerald-900 text-emerald-100">
            {name
              .split(" ")
              .map((n) => n[0])
              .join("")}
          </AvatarFallback>
        </Avatar>
        <div>
          <h4 className="font-medium">{name}</h4>
          <p className="text-sm text-emerald-400">{achievement}</p>
        </div>
      </CardContent>
    </Card>
  )
}

